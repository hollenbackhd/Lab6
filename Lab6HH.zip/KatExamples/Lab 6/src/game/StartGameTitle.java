package game;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class StartGameTitle {
	
	/*_______________________________________________________________________
	 * 
	 * displayTitle() will display the title on the panel provided in the 
	 * constructor parameters.
	 * 
	 ________________________________________________________________________*/
	public static void displayTitle(JPanel mainPanel, String gameTitle) {
		JLabel titleLabel = new JLabel(gameTitle);
		JPanel titlePanel = new JPanel();
		mainPanel.add(titlePanel);
		titlePanel.add(titleLabel);
		titleLabel.setFont(new Font("Baskerville Old Face", Font.BOLD, 50));
		titlePanel.setVisible(true);
		titleLabel.setVisible(true);
	}

}
