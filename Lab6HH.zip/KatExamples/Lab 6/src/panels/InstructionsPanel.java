package panels;

import java.awt.Dimension;
import java.io.FileNotFoundException;

import javax.swing.JPanel;

import instructions.Instructions;

public class InstructionsPanel extends JPanel {
	public InstructionsPanel() throws FileNotFoundException{
		Instructions myDirections = new Instructions();
		myDirections.displayInstructions(this);
		
	}

}
