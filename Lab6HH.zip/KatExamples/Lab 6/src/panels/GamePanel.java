package panels;

import javax.swing.JPanel;

import game.StartGameButton;

public class GamePanel extends JPanel {
	public GamePanel() {
		// called in StartGameButton
		// when this is created we will just call an instance of game on this panel.
		// is displayed when the start button is pressed
		
	}

}
