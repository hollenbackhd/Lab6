package items;
/*
 * Author: Kate Hohenstein
 * Partners: Hannah Hollenback, Kathryn Reese
 * Lab 6
 * 3/10/18
 * Item: set up item attributes and methods
 */
public class Items {
	private String image;
	private int numOfItems;
	private int positionX;
	private int positionY;
	
	public Items(String image, int numOfItems, int positionX, int positionY)
	{
		this.image = image;
		this.numOfItems = numOfItems;
		this.positionX = positionX;
		this.positionY = positionY;
	}
	
	//method to add item image icons to screen, based on # of items, and random X,Y combinations?
	public void showItemImage()
	{
	}
	
	//method to remove image icons from screen when player collides with them
	public void removeItemImage()
	{
	}
	
	//method to get item position (X)
	public int getItemPosX()
	{ 
		return positionX;
	}
	
	//method to get item position (Y)
	public int getItemPosY()
	{ 
		return positionY;
	}
	
	//method to set player position (X)
	public void setX(int positionX)
	{
		this.positionX = positionX;
	}
	
	//method to set player position (y)
	public void setY(int positionY)
	{
		this.positionY = positionY;
	}
	public String getItemBottomX()
	{
		getBottomX = image.getWidth()+Item.getX();
		return getBottomX;
	}
	public String getItemBottomY()
	{
		getBottomY = image.getWidth()+Item.getY();
		return getBottomY;
	
	//method to get number of items
	public int getNumItems()
	{ 
		return numOfItems;
	}
	
	//method to set number of items
	public void setNumItems(int newItemNumber)
	{
		numOfItems = newItemNumber;
	}
	
}

